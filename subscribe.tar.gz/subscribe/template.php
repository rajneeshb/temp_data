<?php

/**
 * @file
 * Template overrides as well as (pre-)process and alter hooks for the
 * Omega Subtheme theme.
 */
